#include "tictacgui.h"
#include <cstdlib>
#include <ctime>
using namespace std;

//const int SCREEN_WIDTH = 600;
//const int SCREEN_HEIGHT = 600;

class Grid {
public:
    Grid();
    char checkLine();
    bool createX(int x, int y);
    bool createO(int x, int y);
    int getCell(int x, int y);
    void setXStatus(bool);
    bool getXStatus();
    void getMove(SDL_Event* e, int filledCells);
private:
    char cells[3][3];
    bool isX;

};

Grid::Grid()
{
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cells[i][j] = '0';
        }
    }
    isX = true;
}

char Grid::checkLine()
{
    if (cells[0][0] == cells[1][0] && cells[0][0] == cells[2][0]) {
        if (cells[0][0] == 'X' || cells[0][0] == 'O')
            return cells[0][0];
    }
    if (cells[0][1] == cells[1][1] && cells[0][1] == cells[2][1]) {
        if (cells[0][1] == 'X' || cells[0][1] == 'O')
            return cells[0][1];
    }
    if (cells[0][2] == cells[1][2] && cells[0][2] == cells[2][2]) {
        if (cells[0][2] == 'X' || cells[0][2] == 'O')
            return cells[0][2];
    }
    if (cells[0][0] == cells[0][1] && cells[0][0] == cells[0][2]) {
        if (cells[0][0] == 'X' || cells[0][0] == 'O')
            return cells[0][0];
    }
    if (cells[1][0] == cells[1][1] && cells[1][0] == cells[1][2]) {
        if (cells[1][0] == 'X' || cells[1][0] == 'O')
            return cells[1][0];
    }
    if (cells[2][0] == cells[2][1] && cells[2][0] == cells[2][2]) {
        if (cells[2][0] == 'X' || cells[2][0] == 'O')
            return cells[2][0];
    }
    if (cells[0][0] == cells[1][1] && cells[0][0] == cells[2][2]) {
        if (cells[0][0] == 'X' || cells[0][0] == 'O')
            return cells[0][0];
    }
    if (cells[0][2] == cells[1][1] && cells[0][2] == cells[2][0]) {
        if (cells[0][2] == 'X' || cells[0][2] == 'O')
            return cells[0][2];
    }
    return '0';
}

bool Grid::createX(int x, int y)
{
    x /= 200;
    y /= 200;
    if (cells[x][y] != 'X' && cells[x][y] != 'O') {
        cells[x][y] = 'X';
        return true;
    }
    else return false;
}

bool Grid::createO(int x, int y)
{
    x /= 200;
    y /= 200;
    if (cells[x][y] != 'X' && cells[x][y] != 'O') {
        cells[x][y] = 'O';
        return true;
    }
    else return false;
}

int Grid::getCell(int x, int y)
{
    return cells[x][y];
}

void Grid::setXStatus(bool status)
{
    isX = status;
}

bool Grid::getXStatus()
{
    return isX;
}

void Grid::getMove(SDL_Event* e, int filledCells)
{
    int newx, newy;
    if (e->type == SDL_MOUSEBUTTONDOWN) {
        SDL_GetMouseState(&newx, &newy);
        if (isX) {
            createX(newx, newy);
        }
        else {
            createO(newx, newy);
        }
        if (filledCells < 8) {
            bool foundMove = false;
            while (!foundMove) {
                if (isX) {
                    foundMove = createO(rand() % 600, rand() % 600);
                    //break;
                }
                else if (!isX)
                    foundMove = createX(rand() % 600, rand() % 600); {
                    //break;
                }
            }
        }
    }


}

int main(int argc, char* argv[])
{
    if (init()) {

        if (loadMedia()) {

            bool quit = false;
            SDL_Event e;

            SDL_SetRenderDrawColor(gRenderer, 0xFF, 0xFF, 0xFF, 0xFF);
            SDL_RenderClear(gRenderer);
            Grid tictacgrid;

            srand (time(NULL));
            int newnum = rand() % 2;

            if (!newnum) {
                tictacgrid.setXStatus(false);
                tictacgrid.createX(rand() % 600, rand() % 600);
            }

            int filledCells = 0;

            while (!quit) {
                while (SDL_PollEvent(&e) != 0) {
                    if (e.type == SDL_QUIT) {
                        quit = true;
                    }
                    else {
                        tictacgrid.getMove(&e, filledCells);
                    }

                    SDL_SetRenderDrawColor(gRenderer, 0xFF, 0xFF, 0xFF, 0xFF);
                    SDL_RenderClear(gRenderer);

                    gGridTexture.render(0,0);
                    filledCells = 0;
                    for (int y = 0; y <= 2; y++) {
                        for (int x = 0; x <= 2; x++) {
                            if (tictacgrid.getCell(x,y) == 'X') {
                                gXTexture.render(x * 200, y * 200);
                                filledCells++;
                            }
                            else if (tictacgrid.getCell(x,y) == 'O') {
                                gOTexture.render(x * 200, y * 200);
                                filledCells++;
                            }
                        }
                    }

                    SDL_RenderPresent(gRenderer);

                    if (tictacgrid.checkLine() != '0') {
                        printf("%c has won!\n", tictacgrid.checkLine());
                        SDL_Delay(1000);
                        quit = true;
                        break;
                    }
                    else if (filledCells >= 9) {
                        printf("A tie!\n");
                        SDL_Delay(1000);
                        quit = true;
                        break;
                    }
                }
            }
        }
        else {
            printf("Media loading error occurred!\n");
        }

    }
    else {
        printf("Initialization error occurred!\n");
    }

    close();
    return 0;
}
