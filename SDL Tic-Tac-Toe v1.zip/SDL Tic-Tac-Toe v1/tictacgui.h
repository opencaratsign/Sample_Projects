#ifndef TICTACGUI_H_INCLUDED
#define TICTACGUI_H_INCLUDED

#include <SDL.h>
#include <SDL_image.h>
#include <iostream>
#include <stdio.h>
using namespace std;

const int SCREEN_WIDTH = 600;
const int SCREEN_HEIGHT = 600;

//----------------------------Class Declarations--------------------------------------//

class LTexture {
public:
    LTexture();
    ~LTexture();

    //destroys texture and frees memory
    void free();

    //loads image file
    bool loadFromFile(string path);

    //renders texture
    void render(int x, int y, SDL_Rect* clip = NULL,
                double angle = 0.0, SDL_Point* center = NULL, SDL_RendererFlip flip = SDL_FLIP_NONE);

    int getWidth();
    int getHeight();

private:
    SDL_Texture* mTexture;
    int mWidth;
    int mHeight;

};

//---------------------------------Global Method Declarations/ Objects--------------------------//

//Initializes all needed SDL libraries and images, etc.
bool init();

bool loadMedia();

void close();

SDL_Window* gWindow = NULL;
SDL_Renderer* gRenderer = NULL;

LTexture gXTexture;
LTexture gOTexture;
LTexture gGridTexture;


//-------------------------------------LTexture's methods---------------------------------------//

LTexture::LTexture()
{
    mTexture = NULL;
    mWidth = 0;
    mHeight = 0;
}

LTexture::~LTexture()
{
    free();
}

void LTexture::free()
{
    if (mTexture != NULL) {
        SDL_DestroyTexture(mTexture);
        mTexture = NULL;
        mWidth = 0;
        mHeight = 0;
    }
}

bool LTexture::loadFromFile(string path)
{
    free();

    SDL_Texture* newTexture = NULL;
    SDL_Surface* loadedSurface = IMG_Load(path.c_str());

    if (loadedSurface != NULL) {
        newTexture = SDL_CreateTextureFromSurface(gRenderer, loadedSurface);

        if (newTexture != NULL) {
            mWidth = loadedSurface -> w;
            mHeight = loadedSurface -> h;
        }
        else {
            printf("Texture for %s couldn't be created. Error: %s\n", path.c_str(), SDL_GetError());
        }
        SDL_FreeSurface(loadedSurface);

    }
    else {
        printf("Surface %s couldn't be loaded! Error: %s\n", path.c_str(), IMG_GetError());
    }

    mTexture = newTexture;

    return mTexture != NULL;
}

void LTexture::render(int x, int y, SDL_Rect* clip,
                      double angle, SDL_Point* center, SDL_RendererFlip flip)
{
    SDL_Rect renderQuad = {x, y, mWidth, mHeight};
    if (clip != NULL) {
        renderQuad.w = clip->w;
        renderQuad.h = clip->h;
    }
    SDL_RenderCopyEx(gRenderer, mTexture, clip, &renderQuad, angle, center, flip);
}

int LTexture::getWidth()
{
    return mWidth;
}

int LTexture::getHeight()
{
    return mHeight;
}

//-----------------------------------Global Methods----------------------------------------//

//Sanity check
//Note: for tic-tac-toe it might be ok, but in the future this might create extra overhead
//with too many function calls.
/*
void check(bool statement, string debugMessage, char sourceMessage[], char errorMessage[])
{
    if (!statement) {
        cout << debugMessage << "\n";
        if (sourceMessage != NULL) {
            printf("The source of the error was traced to %s\n", sourceMessage);
        }
        printf("Error: %s\n", errorMessage);
    }
}
*/

bool init()
{
    bool success = true;

    if (SDL_Init(SDL_INIT_VIDEO) >= 0) {

        //Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

        gWindow = SDL_CreateWindow("Tic-Tac-Toe", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
                                   SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
        if (gWindow != NULL) {

            gRenderer = SDL_CreateRenderer(gWindow, -1,
                                           SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);
            if (gRenderer != NULL) {

                SDL_SetRenderDrawColor(gRenderer, 0xFF, 0xFF, 0xFF, 0xFF);

                int imgFlags = IMG_INIT_PNG;
                if (!(IMG_Init(imgFlags) & imgFlags)) {
                    printf("SDL_image couldn't be initialized! Error: %s\n", IMG_GetError());
                    success = false;
                }

            }
            else {
                printf("Renderer couldn't be created! Error: %s\n", SDL_GetError());
                success = false;
            }

        }
        else {
            printf("Window couldn't be created! Error: %s\n", SDL_GetError());
            success = false;
        }

    }
    else {
        printf("SDL couldn't initialize! Error: %s\n", SDL_GetError());
        success = false;
    }
    return success;
}

bool loadMedia()
{
    bool success = true;
    if (!gXTexture.loadFromFile("x.png")) {
        printf("X.png couldn't be loaded!");
        success = false;
    }

    if (!gOTexture.loadFromFile("o.png")) {
        printf("O.png couldn't be loaded!");
        success = false;
    }

    if (!gGridTexture.loadFromFile("grid.png")) {
        printf("grid.png couldn't be loaded!");
        success = false;
    }
    return success;
}

//Destroys gRenderer and gWindow and quits everything.
void close()
{
    gXTexture.free();
    gOTexture.free();
    gGridTexture.free();
    SDL_DestroyRenderer(gRenderer);
    SDL_DestroyWindow(gWindow);
    gWindow = NULL;
    gRenderer = NULL;

    SDL_Quit();
    IMG_Quit();
}

#endif
