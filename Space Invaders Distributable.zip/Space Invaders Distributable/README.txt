Space Invaders v1.0, coded (mostly) from scratch by Nicholas Lai.

Controls: spacebar to shoot, left and right arrow keys to move ship.

Noticeable bugs:
-No sound. Period. The SDL mixer library couldn't compile.
-One alien explodes for no reason.
-Ship has mostly smooth motion, but sometimes freezes when shifting left and right.
-You may need to "shoot" a few times to get any bullets to come out.

Other Possible Areas for Improvement:
-The red alien.
-A scoring system.
-Walls for protection.
-Menus and hi-score tables.