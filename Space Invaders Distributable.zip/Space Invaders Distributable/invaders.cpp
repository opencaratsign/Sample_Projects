#include "invaders.h"
#include <math.h>
#include <stdlib.h>
#include <time.h>

class Bullet {
public:
    const int BULLET_WIDTH = 5;
    const int BULLET_HEIGHT = 20;
    const int BULLET_VEL = -10;
    Bullet(int shipX, int shipY);

    bool move();
    void render();
    int getX();
    int getY();
    int getWidth();
    int getHeight();
protected:
    int x, y;
    int mVelY;
    int mWidth;
    int mHeight;
};

class AlienBullet: public Bullet {
public:
    const int ALIEN_BULLET_WIDTH = 5;
    const int ALIEN_BULLET_HEIGHT = 10;
    const int ALIEN_BULLET_VEL = 5;

    AlienBullet(int alienX, int alienY, int alienid);
    bool move();
    void render(int hasFlip);

private:
    int id;
};

class Alien {
public:

    const int ALIEN_1_HEIGHT = 16;
    const int ALIEN_1_WIDTH = 16;
    const int ALIEN_2_HEIGHT = 20;
    const int ALIEN_2_WIDTH = 25;
    const int ALIEN_3_HEIGHT = 20;
    const int ALIEN_3_WIDTH = 25;
    const int ALIEN_VEL = 3;

    Alien();
    ~Alien();
    Alien(int alienX, int alienY, int alienID);
    void move(int timer, bool syncedSwitch, int aliensDestroyed);
    bool checkBounds();
    void render(int timer);
    void createBullet();
    void deleteBullet();
    int getX();
    int getY();
    int getWidth();
    int getHeight();
    AlienBullet* mAlienBullet;
protected:
    int x, y;
    int id;
    int mVelX;
    int mWidth, mHeight;
    int maxLeft, maxRight;
};

class Spaceship: public Alien {
public:
    const int SHIP_WIDTH = 26;
    const int SHIP_HEIGHT = 15;
    const int COLLISION_HEIGHT = 10;
    const int SHIP_SPEED = 5;
    Spaceship();
    void handleEvent(SDL_Event* e);
    void move();
    void render();
    void createBullet();
    void deleteBullet();
    //int getX();
    //int getY();
    Bullet* mBullet;

private:
    int numBullets;
    char instruction;
};

//////////////////////////////////Bullet's Methods///////////////////////////////////////////////

Bullet::Bullet(int shipX, int shipY)
{
    x = shipX;
    y = shipY;
    mVelY = BULLET_VEL;
}

bool Bullet::move()
{
    if (y < 0 || y > SCREEN_HEIGHT - mHeight) {
        return false;
    }
    else {
        y += mVelY;
        return true;
    }
}

void Bullet::render()
{
    SDL_Rect bullet = {183, 443, 5, 20};
    gSpriteSheetTexture.render(x, y, &bullet);
}

int Bullet::getX()
{
    return x;
}

int Bullet::getY()
{
    return y;
}

int Bullet::getWidth()
{
    return mWidth;
}

int Bullet::getHeight()
{
    return mHeight;
}


///////////////////////////////////////AlienBullet's Methods///////////////////////////////////

//TODO: make multiple types of alien bullets?

AlienBullet::AlienBullet(int alienX,int alienY,int alienid)
    : Bullet(alienX, alienY)
{
    mWidth = ALIEN_BULLET_WIDTH;
    mHeight = ALIEN_BULLET_HEIGHT;
    mVelY = ALIEN_BULLET_VEL;
    id = alienid;
}

bool AlienBullet::move()
{
    if (y < 0 || y > SCREEN_HEIGHT - mHeight) {
        return false;
    }
    else {
        y += mVelY;
        return true;
    }
}

void AlienBullet::render(int hasFlip)
{
    SDL_Rect bullet2 = {412, 277, 8, 10};
    if (hasFlip % 10 < 5)
        gSpriteSheetTexture.render(x, y, &bullet2, 0.0, NULL, SDL_FLIP_VERTICAL);
    else {
        gSpriteSheetTexture.render(x, y, &bullet2);
    }
}

//////////////////////////////////Alien's Methods//////////////////////////////////

Alien::Alien()
{
    mAlienBullet = NULL;
    x = 0;
    y = 0;
    id = 0;
    mVelX = 0;
    mWidth = 0, mHeight = 0;
}

Alien::Alien(int alienX, int alienY, int alienID)
{
    mAlienBullet = NULL;
    x = alienX;
    y = alienY;
    id = alienID;
    mVelX = ALIEN_VEL;
    maxLeft = x - 30;
    maxRight = x + 20;
    if (id == 1) {
        mWidth = ALIEN_1_WIDTH;
        mHeight = ALIEN_1_HEIGHT;
    }
    else if (id == 2) {
        mWidth = ALIEN_2_WIDTH;
        mHeight = ALIEN_2_HEIGHT;
    }
    else if (id == 3) {
        mWidth = ALIEN_3_WIDTH;
        mHeight = ALIEN_3_HEIGHT;
    }

}

Alien::~Alien()
{

}

//return whether boundary has been found.
void Alien::move(int timer, bool syncedSwitch, int aliensDestroyed)
{
    if (timer % 50 == 0) {

        if (syncedSwitch) {
            mVelX *= -1;
            y += ALIEN_VEL;
        }
        else {
            x += mVelX;
        }

    }

    //short firingRate = 5000 - aliensDestroyed * 5;

    int hasBullet = rand() % (500 - 3*aliensDestroyed);

    if (hasBullet % (500 - 3*aliensDestroyed) == 0) {
        createBullet();
    }

    if (mAlienBullet != NULL) {
        if (!mAlienBullet->move()) {
            deleteBullet();
        }
    }

}

bool Alien::checkBounds()
{
    if (x + mVelX < 0 || x + mVelX > SCREEN_WIDTH - 30) {
        return true;
    }
    return false;
}

void Alien::render(int timer)
{
    if (id == 1 && timer < 50) {
        SDL_Rect alien1 = {6, 226, 17, 17};
        gSpriteSheetTexture.render(x,y, &alien1);
    }
    else if (id == 1 && timer >= 50) {
        SDL_Rect alien1 = {40, 226, 16, 16};
        gSpriteSheetTexture.render(x,y, &alien1);
    }
    else if (id == 2 && timer < 50) {
        SDL_Rect alien2 = {74,225,25,15};
        gSpriteSheetTexture.render(x,y, &alien2);
    }
    else if (id == 2 && timer >= 50) {
        SDL_Rect alien2 = {107,225,25,15};
        gSpriteSheetTexture.render(x,y, &alien2);
    }
    else if (id == 3 && timer < 50) {
        SDL_Rect alien3 = {147, 225, 25, 20};
        gSpriteSheetTexture.render(x, y, &alien3);
    }
    else if (id == 3 && timer >= 50) {
        SDL_Rect alien3 = {179,225,25,20};
        gSpriteSheetTexture.render(x,y, &alien3);
    }

    if (mAlienBullet != NULL) {
        mAlienBullet->render(timer);
    }
}

//Creates 1 bullet object.
void Alien::createBullet()
{
    if (mAlienBullet == NULL) {
        mAlienBullet = new AlienBullet(x + mWidth / 2 - 1, y, 1);
    }
}

void Alien::deleteBullet()
{
    if (mAlienBullet != NULL) {
        delete mAlienBullet;
        mAlienBullet = NULL;
    }
}

int Alien::getX()
{
    return x;
}

int Alien::getY()
{
    return y;
}

int Alien::getWidth()
{
    return mWidth;
}

int Alien::getHeight()
{
    return mHeight;
}

///////////////////////////////////////Spaceship's Methods/////////////////////////////////////

Spaceship::Spaceship()
{
    mWidth = SHIP_WIDTH;
    mHeight = SHIP_HEIGHT;
    x = SCREEN_WIDTH / 2 - SHIP_WIDTH / 2;
    y = SCREEN_HEIGHT - 2 * SHIP_HEIGHT;
    mVelX = 0;
    mBullet = NULL;
    instruction = '\0';
}

void Spaceship::handleEvent(SDL_Event* e)
{
    if (e->type == SDL_KEYDOWN && e->key.repeat == 0) {
        if (e->key.keysym.sym == SDLK_LEFT) {
            instruction = 'l';
        }
        else if (e->key.keysym.sym == SDLK_RIGHT) {
            instruction = 'r';
        }
        else if (e->key.keysym.sym == SDLK_SPACE) {
            instruction = '^';
        }
    }
    else if (e->type == SDL_KEYUP && e->key.repeat == 0) {
        instruction = '\0';
    }
}

void Spaceship::move()
{
    if (instruction == 'l') {
        mVelX = -1*SHIP_SPEED;
    }
    else if (instruction == 'r') {
        mVelX = SHIP_SPEED;
    }
    else if (instruction == '^') {
        //instruction = ' ';
        createBullet();
    }

    x += mVelX;
    if (x < 0) {
        x -= mVelX;
    }
    else if (x > SCREEN_WIDTH - SHIP_WIDTH) {
        x -= mVelX;
    }
    mVelX = 0;

    if (mBullet != NULL) {
        if (!mBullet->move()) {
            delete mBullet;
            mBullet = NULL;
        }
    }
}

void Spaceship::render()
{
    SDL_Rect ship = {276, 224, 30, 25};
    gSpriteSheetTexture.render(x, y, &ship);

    if (mBullet != NULL) {
        mBullet->render();
    }
}

//Creates 1 bullet object.
void Spaceship::createBullet()
{
    if (mBullet == NULL) {
        mBullet = new Bullet(x + SHIP_WIDTH / 2 - 1, y);
        //cout << "Bullet created!\n";
    }
}

void Spaceship::deleteBullet()
{
    if (mBullet != NULL) {
        delete mBullet;
        mBullet = NULL;
    }
}




//------------------------------------------Global Methods------------------------------------//

bool checkCollision(Alien* a, Bullet* b)
{
    //potentially add || a == NULL if needed
    if (b == NULL) {
        return false;
    }

    if (a->getX() + a->getWidth() < b->getX()) {
        //printf("%d,%d \t %d,%d\n", a->getX(), a->getY(), b->getX(), b->getY());
        //printf("%d,%d \t %d,%d\n", a->getWidth(), a->getHeight(), b->getWidth(), b->getHeight());
        //printf("whatup!\n");
        return false;
    }
    if (a->getX() > b->getX() + b->getWidth()) {
        //printf("%d %d, %d %d\n", a->getX(), a->getY(), b->getX(), b->getY());
        //printf("%d %d, %d %d\n", a->getWidth(), a->getHeight(), b->getWidth(), b->getHeight());
        //printf("whatup!2\n");
        return false;
    }
    if (a->getY() + a->getHeight() < b->getY()) {
        //printf("%d %d, %d %d\n", a->getX(), a->getY(), b->getX(), b->getY());
        //printf("%d %d, %d %d\n", a->getWidth(), a->getHeight(), b->getWidth(), b->getHeight());
        //printf("whatup!3\n");
        return false;
    }
    if (a->getY() > b->getY() + b->getHeight()) {
        //printf("%d %d, %d %d\n", a->getX(), a->getY(), b->getX(), b->getY());
        //printf("%d %d, %d %d\n", a->getWidth(), a->getHeight(), b->getWidth(), b->getHeight());
        //printf("whatup!4\n");
        return false;
    }

    return true;
}

bool checkCollision2(Spaceship* a, AlienBullet* b)
{
    //potentially add || a == NULL if needed
    if (b == NULL) {
        return false;
    }

    //potentially add || a == NULL if needed
    if (b == NULL) {
        return false;
    }

    if (a->getX() + a->getWidth() < b->getX()) {
        //printf("%d,%d \t %d,%d\n", a->getX(), a->getY(), b->getX(), b->getY());
        //printf("%d,%d \t %d,%d\n", a->getWidth(), a->getHeight(), b->getWidth(), b->getHeight());
        //printf("whatup!\n");
        return false;
    }
    if (a->getX() > b->getX() + b->getWidth()) {
        //printf("%d %d, %d %d\n", a->getX(), a->getY(), b->getX(), b->getY());
        //printf("%d %d, %d %d\n", a->getWidth(), a->getHeight(), b->getWidth(), b->getHeight());
        //printf("whatup!2\n");
        return false;
    }
    if (a->getY() + a->getHeight() < b->getY()) {
        //printf("%d %d, %d %d\n", a->getX(), a->getY(), b->getX(), b->getY());
        //printf("%d %d, %d %d\n", a->getWidth(), a->getHeight(), b->getWidth(), b->getHeight());
        //printf("whatup!3\n");
        return false;
    }
    if (a->getY() > b->getY() + b->getHeight()) {
        //printf("%d %d, %d %d\n", a->getX(), a->getY(), b->getX(), b->getY());
        //printf("%d %d, %d %d\n", a->getWidth(), a->getHeight(), b->getWidth(), b->getHeight());
        //printf("whatup!4\n");
        return false;
    }

    return true;
}

int main(int argc, char* argv[])
{
    Spaceship ship;

    int rowSize = 5;
    int colSize = 10;
    int aliensDestroyed = 0;

    Alien* aliens[10][10];
    bool hit[10][10];
    short destroyed[10][10];
    bool boundaryHit = false;
    bool shotByAlien = false;
    bool gameFinished = false;

    short numLives = 3;

    srand(time(NULL));

    for (int i = 0; i < colSize; i++)
        for (int j = 0; j < rowSize; j++) {
            aliens[i][j] = new Alien(50 + i * 40, 40+ 40*j, (j+3)/2);
            destroyed[i][j] = 0;
        }

    if (init()) {

        if (loadMedia()) {

            bool quit = false;

            SDL_Event e;

            int loopTime = 0;

            while (!quit) {
                while (SDL_PollEvent(&e) != 0) {

                    if (e.type == SDL_QUIT) {
                        quit = true;
                    }
                    else
                    ship.handleEvent(&e);

                }

                ship.move();

                boundaryHit = false;

                for (int i = 0; i < colSize; i++) {
                    for (int j = 0; j < rowSize; j++) {
                        if (!hit[i][j]) {
                            //if (aliens[i][j].checkBounds()){}
                            if (aliens[i][j]->checkBounds()) {
                                boundaryHit = true;
                            }
                        }
                    }
                }

                for (int i = 0; i < colSize; i++) {
                    for (int j = 0; j < rowSize; j++) {
                        if (!hit[i][j]) {
                            //aliens[i][j].move(loopTime, boundaryHit, aliensDestroyed);
                            aliens[i][j]->move(loopTime, boundaryHit, aliensDestroyed);
                            //if (checkCollision2(&ship, aliens[i][j].mAlienBullet)) {
                            if (checkCollision2(&ship, aliens[i][j]->mAlienBullet)) {
                                shotByAlien = true;
                                //aliens[i][j].deleteBullet();
                                aliens[i][j]->deleteBullet();
                            }
                        }
                    }
                }

                //TODO: Figure out why it's acting so weird in terms of deleting multiple aliens
                if (ship.mBullet != NULL)
                    for (int i = 0; i < colSize; i++) {
                        for (int j = 0; j < rowSize; j++) {
                            if (!hit[i][j]) {
                                if (checkCollision(aliens[i][j], ship.mBullet)) {
                                    //printf("Collision for alien %d\n", i);
                                    hit[i][j] = 1;
                                    aliensDestroyed++;

                                    ship.deleteBullet();
                                }
                            }
                        }
                    }

                SDL_SetRenderDrawColor(gRenderer, 0, 0, 0, 0);
                SDL_RenderClear(gRenderer);

                for (int i = 0; i < colSize; i++) {
                    for (int j = 0; j < rowSize; j++) {
                        if (!hit[i][j])
                            aliens[i][j]->render(loopTime);
                        else if (destroyed[i][j] <= 10) {
                            SDL_Rect alienExplosion = {437, 276,26,14};
                            gSpriteSheetTexture.render(
                                aliens[i][j]->getX() - (13 - aliens[i][j]->getWidth()/2),
                                aliens[i][j]->getY(), &alienExplosion);
                            destroyed[i][j]++;
                        }
                    }
                }

                if (shotByAlien) {
                    SDL_Rect destroyed = {367,275,30,25};
                    if (loopTime % 10 < 5) {
                        gSpriteSheetTexture.render(ship.getX(), ship.getY(), &destroyed);
                    }
                    else {
                        gSpriteSheetTexture.render(ship.getX(), ship.getY(), &destroyed,
                                                    0.0, NULL, SDL_FLIP_HORIZONTAL);
                    }
                    if (loopTime % 20 == 0) {
                        if (numLives == 1)
                            quit = true;
                        else {
                            shotByAlien = false;
                            numLives--;
                        }
                    }
                }
                else {
                    ship.render();
                }

                gLivesTextTexture.render(SCREEN_WIDTH / 2,0);

                for (int i = 1; i <= numLives; i++) {
                    SDL_Rect ship = {276, 224, 30, 25};
                    gSpriteSheetTexture.render(SCREEN_WIDTH / 2 + 20 + 30 * i, 0, &ship);
                }

                if (aliensDestroyed == 49) {
                    cout << "You've won!\n";
                    gameFinished = true;
                    gWinningTextTexture.render(SCREEN_WIDTH / 2 - gWinningTextTexture.getWidth()/2,
                                               SCREEN_HEIGHT / 2 - gWinningTextTexture.getHeight()/2);
                    quit = true;
                }

                SDL_RenderPresent(gRenderer);

                loopTime++;

                if (loopTime > 100) {
                    loopTime = 0;
                }

                if (gameFinished) {
                    SDL_Delay(5000);
                }
            }
            cout << "Game over.\n";

            for (int i = 0; i < colSize; i++)
            for (int j = 0; j < rowSize; j++)
            if (aliens[i][j] != NULL) {
                delete aliens[i][j];
                aliens[i][j] = NULL;
            }

        }
        else {
            printf("Media loading error occurred.\n");
        }

    }
    else {
        printf("Initialization error occurred.\n");
    }

    close();
    return 0;
}
